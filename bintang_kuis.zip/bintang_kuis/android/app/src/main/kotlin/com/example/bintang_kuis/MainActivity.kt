package com.example.bintang_kuis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
